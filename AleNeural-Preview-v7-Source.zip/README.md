# AleNeural AI System OS — A51 concept v7

This is an interactive HTML concept, revised gradually from Baba's supplied second reference (v5). It is not firmware or an APK. No phone connection is required.

Run `npm run build` with Node.js 20 or later, then open `dist/index.html`. No install or API key is needed for this baseline. The editable template uses four image placeholders; original reference images are separate PNG files in `assets/`.

Preserve the baseline neon cyan/purple style and all three tabs, including Home/listening simulation, portal and apps/folder navigation. Home has one large clock near the top, raised weather/location, 100% inside the battery, a lowered Sonordroid–AleCore label, and a simple lowered Hey AleCore text/microphone control. Microphone interaction is a simulation.

See the repository's COPILOT_TASK.md for the requested reusable scripts. The first refactor must preserve the baseline appearance and behavior. Future design changes come from Baba, one revision at a time.
