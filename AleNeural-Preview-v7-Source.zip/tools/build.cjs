const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const root = path.resolve(__dirname, '..');
const assets = ['home', 'listening', 'portal', 'apps'];
let html = fs.readFileSync(path.join(root, 'src/preview.template.html'), 'utf8');
for (const [i, name] of assets.entries()) {
  const token = `__ASSET_${i + 1}__`;
  if (html.split(token).length !== 2) throw new Error(`Expected exactly one ${token}`);
  html = html.replace(token, `data:image/png;base64,${fs.readFileSync(path.join(root, 'assets', `${name}.png`)).toString('base64')}`);
}
if (/__ASSET_\d+__/.test(html)) throw new Error('Unresolved image placeholder');
fs.mkdirSync(path.join(root, 'dist'), { recursive: true });
fs.writeFileSync(path.join(root, 'dist/index.html'), html);
console.log(JSON.stringify({ file: 'dist/index.html', bytes: Buffer.byteLength(html), sha256: crypto.createHash('sha256').update(html).digest('hex') }));
